/* Shared Grade 2/3 maths: code-drawn Halloween patterns and number sense. */
const MATH_PAGES=[
{title:'Pumpkin parade',questions:[
{prompt:'What comes next in this pattern?',choices:['Pumpkin','Ghost','Bat'],answer:0,skill:'Repeating patterns',visual:{type:'pattern',items:['pumpkin','ghost','pumpkin','ghost','?']},description:'Pumpkin, ghost, pumpkin, ghost, blank.'},
{prompt:'How many pumpkins are shown?',choices:['10','12','14'],answer:1,skill:'Counting',visual:{type:'array',icon:'pumpkin',rows:3,cols:4},description:'Three rows of four pumpkins.'},
{prompt:'There are 10 treats and 7 more. How many altogether?',choices:['15','17','19'],answer:1,skill:'Adding within 20',visual:{type:'groups',counts:[10,7],icon:'candy'},description:'A group of ten treats and a group of seven treats.'}]},
{title:'Spider numbers',questions:[
{prompt:'Count by 2s. Which number is missing?',choices:['7','8','9'],answer:1,skill:'Skip counting',visual:{type:'numbers',items:['2','4','6','?','10']},description:'Two, four, six, blank, ten.'},
{prompt:'What number is 3 tens and 4 ones?',choices:['43','34','30'],answer:1,skill:'Tens and ones',visual:{type:'place',tens:3,ones:4},description:'Three ten sticks and four single blocks.'},
{prompt:'Which number is greater?',choices:['18','15','They are equal'],answer:0,skill:'Comparing numbers',visual:{type:'numbers',items:['18','or','15']},description:'Compare eighteen and fifteen.'}]},
{title:'Potion patterns',questions:[
{prompt:'What comes next in this pattern?',choices:['Hat','Bat','Ghost'],answer:0,skill:'Repeating patterns',visual:{type:'pattern',items:['hat','bat','bat','hat','bat','bat','?']},description:'Hat, bat, bat, hat, bat, bat, blank.'},
{prompt:'Which number belongs in the empty spot?',choices:['13','16','18'],answer:1,skill:'Number order',visual:{type:'numbers',items:['14','15','?','17']},description:'Fourteen, fifteen, blank, seventeen.'},
{prompt:'There are 20 treats. Give away 6. How many remain?',choices:['12','14','16'],answer:1,skill:'Subtracting within 20',visual:{type:'equation',items:['20','−','6','=','?']},description:'Twenty minus six equals blank.'}]},
{title:'Owl arrays',questions:[
{prompt:'The pattern grows by 3. What comes next?',choices:['10','11','12'],answer:2,skill:'Growing patterns',visual:{type:'numbers',items:['3','6','9','?']},description:'Three, six, nine, blank. Add three each time.'},
{prompt:'How many owls are in the two rows?',choices:['7','10','12'],answer:1,skill:'Arrays and counting',visual:{type:'array',icon:'owl',rows:2,cols:5},description:'Two rows of five owls.'},
{prompt:'Count the Canadian coins. What is the total?',choices:['35 cents','40 cents','45 cents'],answer:1,skill:'Counting coins',visual:{type:'coins',items:[25,10,5]},description:'One twenty-five-cent coin, one ten-cent coin, one five-cent coin.'}]},
{title:'Haunted house numbers',questions:[
{prompt:'Count by 10s. Which number is missing?',choices:['35','40','60'],answer:1,skill:'Skip counting',visual:{type:'numbers',items:['10','20','30','?','50']},description:'Ten, twenty, thirty, blank, fifty.'},
{prompt:'Which number is greater?',choices:['49','94','They are equal'],answer:1,skill:'Place value and comparison',visual:{type:'numbers',items:['49','or','94']},description:'Compare forty-nine and ninety-four.'},
{prompt:'Eight treats plus how many more make 15?',choices:['5','7','9'],answer:1,skill:'Missing addends',visual:{type:'equation',items:['8','+','?','=','15']},description:'Eight plus blank equals fifteen.'}]},
{title:'Moonlight patterns',questions:[
{prompt:'What comes next in this pattern?',choices:['Pumpkin','Bat','Owl'],answer:0,skill:'Repeating patterns',visual:{type:'pattern',items:['pumpkin','pumpkin','bat','pumpkin','pumpkin','bat','?']},description:'Pumpkin, pumpkin, bat, pumpkin, pumpkin, bat, blank.'},
{prompt:'What number is 5 tens and 2 ones?',choices:['25','52','50'],answer:1,skill:'Tens and ones',visual:{type:'place',tens:5,ones:2},description:'Five ten sticks and two single blocks.'},
{prompt:'Three groups have 4 spiders each. How many spiders?',choices:['7','10','12'],answer:2,skill:'Equal groups',visual:{type:'groups',counts:[4,4,4],icon:'spider'},description:'Three groups of four spiders.'}]},
{title:'Party number puzzle',questions:[
{prompt:'Count back by 2s. Which number is missing?',choices:['13','14','15'],answer:1,skill:'Shrinking patterns',visual:{type:'numbers',items:['20','18','16','?','12']},description:'Twenty, eighteen, sixteen, blank, twelve.'},
{prompt:'Which number can make pairs with none left over?',choices:['6','7','9'],answer:0,skill:'Even numbers',visual:{type:'array',icon:'ghost',rows:2,cols:3},description:'Six ghosts arranged in three pairs.'},
{prompt:'What is 10 more than 27?',choices:['28','37','47'],answer:1,skill:'Adding ten',visual:{type:'equation',items:['27','+','10','=','?']},description:'Twenty-seven plus ten equals blank.'}]}];
function storyCount(level=state?.level||chosenLevel){return LEVELS[level].sections.length}
function studentPageIndex(){return state.p*2+(state.stage==='math'?1:0)}
function studentPageCount(level=state?.level||chosenLevel){return storyCount(level)*2-1}
function collectedClues(){return LEVELS[state.level].clueAfter?.[state.p]||Math.min(state.p+1,5)}
function storyArtPage(level,p){return LEVELS[level].artPages?.[p]??p%6}
function mathIcon(kind,x,y,scale=1){
let drawing='';
if(kind==='pumpkin')drawing='<ellipse cx="0" cy="3" rx="19" ry="15" fill="#fff0ca"/><path d="M0-12L3-22M-7-10Q-16 2-7 16M7-10Q16 2 7 16"/><path d="M-11 0l4-5 4 5M3 0l4-5 4 5M-8 8q8 8 16 0"/>';
else if(kind==='ghost')drawing='<path d="M-17 20V-2c0-26 34-26 34 0v22l-9-6-8 6-8-6z" fill="white"/><circle cx="-6" cy="-2" r="2" fill="#222"/><circle cx="6" cy="-2" r="2" fill="#222"/><ellipse cx="0" cy="8" rx="3" ry="4"/>';
else if(kind==='bat')drawing='<path d="M-4-5L-28-17-23 8-13 2-7 13 0 7 7 13 13 2 23 8 28-17 4-5 3-14 0-10-3-14z" fill="#eee6f7"/>';
else if(kind==='hat')drawing='<path d="M-18 12L1-26 16 12z" fill="#eee6f7"/><ellipse cx="0" cy="13" rx="28" ry="6" fill="white"/><path d="M-11 2H11"/>';
else if(kind==='spider')drawing='<ellipse cx="0" cy="0" rx="10" ry="12" fill="white"/><path d="M-8-7l-10-8-4 6M-10-2l-12-3-3 7M-10 4l-11 5-2 6M-7 9l-8 10-6-1M8-7l10-8 4 6M10-2l12-3 3 7M10 4l11 5 2 6M7 9l8 10 6-1"/><circle cx="-3" cy="-3" r="1"/><circle cx="3" cy="-3" r="1"/>';
else if(kind==='owl')drawing='<ellipse cx="0" cy="3" rx="17" ry="21" fill="#fff1d3"/><path d="M-15-7l-3-18 13 10M15-7l3-18-13 10"/><circle cx="-6" cy="-3" r="6" fill="white"/><circle cx="6" cy="-3" r="6" fill="white"/><path d="M-3 5h6l-3 5z"/><circle cx="-6" cy="-3" r="1"/><circle cx="6" cy="-3" r="1"/>';
else if(kind==='candy')drawing='<rect x="-11" y="-7" width="22" height="14" rx="4" fill="#fff1d3"/><path d="M-11-4l-9-5v18l9-5M11-4l9-5v18l-9-5M-4-6L4 6"/>';
else drawing='<text x="0" y="10" text-anchor="middle" font-family="Arial" font-size="36" fill="#513a20" stroke="none">?</text>';
return '<g transform="translate('+x+' '+y+') scale('+scale+')" stroke="#493c32" stroke-width="1.7" stroke-linejoin="round">'+drawing+'</g>';
}
function mathHasBlank(question){return question.visual.items?.includes('?')||false}
function mathDropSlot(question,interaction,x,y){
const index=interaction.question,answer=interaction.answer,choice=question.choices[Number(answer)],filled=answer!==undefined&&choice!==undefined;
const picture=filled&&question.visual.type==='pattern'?mathIcon(choice.toLowerCase(),x,y,.72):'<text x="'+x+'" y="'+(y+7)+'" text-anchor="middle" font-family="Arial" font-size="'+(filled?23:13)+'" font-weight="700" fill="#493c32">'+escapeHTML(filled?choice:'Drop here')+'</text>';
return '<g role="button" tabindex="0" class="math-drop '+(filled?'filled':'')+'" data-math-drop="'+index+'" data-index="'+(filled?answer:'')+'" aria-label="Answer area for question '+(index+1)+': '+escapeHTML(filled?choice:'empty')+'"><rect x="'+(x-27)+'" y="'+(y-28)+'" width="54" height="56" rx="8" fill="'+(filled?'#eee2f6':'#fff9e9')+'" stroke="#926934" stroke-width="2" stroke-dasharray="'+(filled?'0':'5 4')+'"/>'+picture+'</g>';
}
function mathVisualSVG(question,interaction=null){
const v=question.visual;let inside='';
if(v.type==='pattern')v.items.forEach((item,i)=>inside+=interaction&&item==='?'?mathDropSlot(question,interaction,30+i*300/Math.max(1,v.items.length-1),83):mathIcon(item,30+i*300/Math.max(1,v.items.length-1),83,v.items.length>5?.75:1));
else if(v.type==='array'){const dx=Math.min(55,280/v.cols),dy=47,start=180-(v.cols-1)*dx/2;for(let r=0;r<v.rows;r++)for(let c=0;c<v.cols;c++)inside+=mathIcon(v.icon,start+c*dx,40+r*dy,.67)}
else if(v.type==='groups'){const width=320/v.counts.length;v.counts.forEach((count,group)=>{let x=20+group*width;inside+='<rect x="'+x+'" y="19" width="'+(width-9)+'" height="124" rx="10" fill="none" stroke="#b39c79"/>';for(let i=0;i<count;i++)inside+=mathIcon(v.icon,x+18+(i%Math.min(5,Math.ceil(count/2)))*((width-40)/Math.max(1,Math.min(5,Math.ceil(count/2))-1)),49+Math.floor(i/Math.min(5,Math.ceil(count/2)))*43,.6)})}
else if(v.type==='place'){for(let i=0;i<v.tens;i++){let x=35+i*25;inside+='<rect x="'+x+'" y="22" width="16" height="110" fill="#fff1d3" stroke="#493c32"/>';for(let n=1;n<10;n++)inside+='<path d="M'+x+' '+(22+n*11)+'h16" stroke="#493c32"/>'}for(let i=0;i<v.ones;i++)inside+='<rect x="'+(235+i%4*24)+'" y="'+(49+Math.floor(i/4)*24)+'" width="17" height="17" fill="#eee6f7" stroke="#493c32"/>'}
else if(v.type==='coins')v.items.forEach((number,i)=>inside+='<circle cx="'+(71+i*108)+'" cy="78" r="36" fill="#fff7df" stroke="#493c32" stroke-width="2"/><text x="'+(71+i*108)+'" y="86" text-anchor="middle" font-family="Arial" font-size="25" fill="#222">'+number+'¢</text>');
else v.items.forEach((item,i)=>inside+=interaction&&item==='?'?mathDropSlot(question,interaction,28+i*304/Math.max(1,v.items.length-1),83):'<text x="'+(28+i*304/Math.max(1,v.items.length-1))+'" y="92" text-anchor="middle" font-family="Arial" font-size="'+(v.items.length>4?29:34)+'" font-weight="700" fill="#493c32">'+escapeHTML(item)+'</text>');
return '<svg class="math-diagram" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 164" role="'+(interaction?'group':'img')+'" aria-label="'+escapeHTML(question.description)+'">'+inside+'</svg>';
}
let selectedMathChoice=null,mathDrag=null,mathScope='';
function mathChoicePicture(question,choice){return question.visual.type==='pattern'?'<svg class="math-choice-picture" aria-hidden="true" viewBox="-32 -30 64 58">'+mathIcon(choice.toLowerCase(),0,0,1)+'</svg>':''}
function mathQuestionMarkup(question,index,answer){
const filled=answer!==undefined&&question.choices[Number(answer)]!==undefined,selected=selectedMathChoice?.question===index;
return '<fieldset class="math-question" data-math-card="'+index+'"><legend>'+(index+1)+'. '+escapeHTML(question.prompt)+'</legend>'+mathVisualSVG(question,{question:index,answer})+(mathHasBlank(question)?'':'<button type="button" class="math-answer-drop math-drop '+(filled?'filled':'')+'" data-math-drop="'+index+'" data-index="'+(filled?answer:'')+'" aria-label="Answer area for question '+(index+1)+': '+escapeHTML(filled?question.choices[Number(answer)]:'empty')+'">'+escapeHTML(filled?question.choices[Number(answer)]:'Drop answer here')+'</button>')+'<div class="math-options math-bank" data-math-bank="'+index+'" role="group" aria-label="Answer choices for question '+(index+1)+'">'+question.choices.map((choice,j)=>'<button type="button" class="math-choice '+(selected&&selectedMathChoice.index===String(j)?'selected':'')+' '+(String(answer)===String(j)?'placed':'')+'" data-math-choice="'+index+'" data-index="'+j+'" aria-label="Question '+(index+1)+' choice '+escapeHTML(choice)+'" aria-pressed="'+(selected&&selectedMathChoice.index===String(j))+'">'+mathChoicePicture(question,choice)+'<span>'+escapeHTML(choice)+'</span></button>').join('')+'</div><p class="math-help" role="status">'+(selected?'Drop “'+escapeHTML(question.choices[Number(selectedMathChoice.index)])+'” into this question’s answer area.':'Drag a choice to the answer box, or tap a choice and then the box.')+'</p></fieldset>';
}
function renderMath(){
const p=state.p,page=MATH_PAGES[p],answers=state.mathAnswers?.[p]||{},scope=state.level+'|'+state.sid+'|'+p;
if(mathScope!==scope){mathScope=scope;selectedMathChoice=null}state.mathView??=0;
$('app').innerHTML='<main class="shell math-shell"><header class="topbar"><div class="wordmark">Halloween maths</div><div class="top-info"><span class="badge">'+escapeHTML(state.sid)+' · '+state.level+'</span><span class="badge">Page '+(studentPageIndex()+1)+' / '+studentPageCount()+'</span><span class="badge">Math break '+(p+1)+' / '+MATH_PAGES.length+'</span></div></header><div class="math-heading"><h1 id="sectionTitle" tabindex="-1">'+escapeHTML(page.title)+'</h1><p>Drag an answer into each box. You can also tap an answer, then its box.</p></div><nav class="math-tabs" aria-label="Math questions">'+page.questions.map((_,i)=>'<button data-math-view="'+i+'" class="'+(state.mathView===i?'active':'')+'">Question '+(i+1)+'</button>').join('')+'</nav><div class="math-cards" data-current="'+state.mathView+'">'+page.questions.map((q,i)=>mathQuestionMarkup(q,i,answers['q'+i])).join('')+'</div><div class="math-lock"><span id="mathAnswerStatus">'+Object.keys(answers).length+' / 3 answered</span><button id="nextBtn" class="primary">🔒 Lock maths & continue →</button></div><footer class="bottom-bar '+(hasNarration(state.level)?'with-narration':'')+'">'+(hasNarration(state.level)?narrationControls():'')+'<span id="saveStatus"></span><span id="pageTime"></span></footer></main>';
document.querySelectorAll('[data-math-view]').forEach(button=>button.onclick=()=>{finishMathDrag();selectedMathChoice=null;state.mathView=Number(button.dataset.mathView);renderMath();store()});
bindMathDrag();bindTeacherVoice();$('nextBtn').onclick=requestNext;bindNarration();timer();updateStorageNotice();
}
function placeMathChoice(question,index){
if(syncLatest()||state?.done||state?.stage!=='math')return;
if(!MATH_PAGES[state.p]?.questions[question]?.choices[Number(index)]||!/^\d+$/.test(String(index)))return;
state.mathAnswers||={};state.mathAnswers[state.p]||={};state.mathAnswers[state.p]['q'+question]=String(index);selectedMathChoice=null;navpush('math_answer_changed','q'+question);renderMath();
}
function clearMathChoice(question){
if(syncLatest()||state?.done||state?.stage!=='math')return;
delete (state.mathAnswers?.[state.p]||{})['q'+question];selectedMathChoice=null;navpush('math_answer_cleared','q'+question);renderMath();
}
function clickMathControl(button){
stopNarration();
if(button.dataset.mathChoice!==undefined){const question=Number(button.dataset.mathChoice),index=button.dataset.index;selectedMathChoice=selectedMathChoice?.question===question&&selectedMathChoice.index===index?null:{question,index};renderMath()}
else{const question=Number(button.dataset.mathDrop);if(selectedMathChoice?.question===question)placeMathChoice(question,selectedMathChoice.index);else if(button.dataset.index!=='')clearMathChoice(question)}
}
function finishMathDrag(){document.querySelectorAll('.math-drop-ready').forEach(el=>el.classList.remove('math-drop-ready'));document.querySelector('.math-drag-ghost')?.remove();mathDrag=null}
function bindMathDrag(){
document.querySelectorAll('[data-math-choice],[data-math-drop]').forEach(button=>{
button.onclick=e=>{if(e.detail===0)clickMathControl(button)};
button.onkeydown=e=>{if(button.tagName.toLowerCase()==='g'&&(e.key==='Enter'||e.key===' ')){e.preventDefault();clickMathControl(button)}};
button.onpointerdown=e=>{
if(e.button!==0)return;e.preventDefault();stopNarration();
mathDrag={button,question:Number(button.dataset.mathChoice??button.dataset.mathDrop),index:button.dataset.index,sourceDrop:button.dataset.mathDrop!==undefined,x:e.clientX,y:e.clientY,dragging:false};button.setPointerCapture(e.pointerId);
};
button.onpointermove=e=>{
const drag=mathDrag;if(!drag||drag.button!==button||drag.index==='')return;
if(!drag.dragging&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<7)return;
drag.dragging=true;let ghost=document.querySelector('.math-drag-ghost');
if(!ghost){ghost=document.createElement('div');ghost.className='cloze-drag-ghost math-drag-ghost';ghost.setAttribute('aria-hidden','true');ghost.textContent=MATH_PAGES[state.p].questions[drag.question].choices[Number(drag.index)];document.body.append(ghost)}
ghost.style.left=e.clientX+'px';ghost.style.top=e.clientY+'px';
document.querySelectorAll('.math-drop-ready').forEach(el=>el.classList.remove('math-drop-ready'));
const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-math-drop]');if(target&&Number(target.dataset.mathDrop)===drag.question)target.classList.add('math-drop-ready');
};
button.onpointerup=e=>{
const drag=mathDrag;if(!drag||drag.button!==button)return;e.preventDefault();
const target=document.elementFromPoint(e.clientX,e.clientY),drop=target?.closest('[data-math-drop]'),bank=target?.closest('[data-math-bank]');finishMathDrag();
if(!drag.dragging){clickMathControl(button);return}
if(drop&&Number(drop.dataset.mathDrop)===drag.question)placeMathChoice(drag.question,drag.index);
else if(drag.sourceDrop&&bank&&Number(bank.dataset.mathBank)===drag.question)clearMathChoice(drag.question);
};
button.onpointercancel=finishMathDrag;
});
}

function mathReportRows(current){
return MATH_PAGES.flatMap((page,p)=>page.questions.map((question,i)=>{const answer=current.mathAnswers?.[p]?.['q'+i],response=answer===undefined?'':question.choices[Number(answer)],correct=question.choices[question.answer];return {section:p+1,item:'N'+(i+1),type:'Halloween maths',skill:question.skill,prompt:question.prompt,options:question.choices.slice(),response,correct,mark:response===correct?1:0,seconds:Math.round(current.mathTimes?.[p]||0),visualDescription:question.description}}));
}
