'use strict';
/* Escaping reused from the Peter & Luna reader; storage, timing, navigation logging
   and per-item result records adapted from Cornercat's assessment routines. */
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=id=>document.getElementById(id);
const CAT_NAME='tinyPumpkin_cloze_math_v3';
// Downloaded files and privacy-restricted browsers may block web storage.
// Keep assessment navigation working in the open tab in every storage mode.
function createAttemptStorage(browser){
const memory=new Map();let backend=null,mode='memory';
for(const name of ['localStorage','sessionStorage']){
try{const candidate=browser[name],probe=CAT_NAME+'_storage_probe';candidate.setItem(probe,'1');candidate.removeItem(probe);backend=candidate;mode=name==='localStorage'?'local':'session';break}catch{}
}
return {
get mode(){return mode},
getItem(key){if(backend){try{const value=backend.getItem(key);if(value===null)memory.delete(key);else memory.set(key,value);return value}catch{backend=null;mode='memory'}}return memory.get(key)??null},
setItem(key,value){memory.set(key,value);if(backend){try{backend.setItem(key,value)}catch{backend=null;mode='memory'}}},
removeItem(key){memory.delete(key);if(backend){try{backend.removeItem(key)}catch{backend=null;mode='memory'}}}
};
}
const attemptStorage=createAttemptStorage(window);
function progressNotice(){return attemptStorage.mode==='local'?'Saved on this device · Earlier sections lock when you continue':attemptStorage.mode==='session'?'Saved in this tab · Earlier sections stay locked':'Temporary progress · Keep this tab open'}
function updateStorageNotice(){const target=$('saveStatus');if(target)target.textContent=progressNotice()}
const HALLOWEEN_IDS=['Pumpkin','Ghost','Bat','Spider','Spiderweb','Black Cat','Skull','Cauldron','Broomstick','Witch Hat','Lantern','Candle','Mask','Scarecrow','Moon','Spellbook','Tombstone','Candy Corn','Treat Bag','Haunted House'];
const now=()=>new Date().toISOString();
const art=window.INLINE_ART||'assets/story-art.png';
document.documentElement.style.setProperty('--art','url("'+art+'")');
document.documentElement.style.setProperty('--yards','url("'+(window.INLINE_YARDS||'assets/house-art.png?v=2')+'")');
let resetTarget=null;
let chosenLevel='A',state=null,pageStart=null,view='story',selectedHouse=1,soundOn=false,audioContext;
const props={Owl:'🦉',Ghost:'👻',Spider:'🕷️',Bat:'🦇',Cat:'🐈‍⬛',Skeleton:'💀'};
const lamps={Purple:'#9959c7',Blue:'#4289d3',Amber:'#e9a629',Green:'#58a76b'};
function storageKey(level=state?.level,id=state?.sid){return CAT_NAME+(level==='A'?'_simple4':'')+'_'+level+'_'+id}
function load(level,id){try{const s=JSON.parse(attemptStorage.getItem(storageKey(level,id))||'null');return s&&s.version===(level==='A'?4:2)?s:null}catch{return null}}
function store(){if(!state)return true;attemptStorage.setItem(storageKey(),JSON.stringify(state));updateStorageNotice();return true}
function navpush(action,detail=''){if(!state)return;state.events.push({action,section:state.p+1,time:now(),detail});store()}
function elapsed(){return ((state.stage==='math'?state.mathTimes:state.pageTimes)[state.p]||0)+(pageStart?Math.max(0,(Date.now()-pageStart)/1000):0)}
function savePage(){if(state&&!state.done&&pageStart){(state.stage==='math'?state.mathTimes:state.pageTimes)[state.p]=elapsed();pageStart=Date.now();store()}}
function syncLatest(){if(!state)return;const s=load(state.level,state.sid);if(s&&(s.p*2+(s.stage==='math'?1:0)>studentPageIndex()||s.done&&!state.done)){state=s;pageStart=state.done?null:Date.now();render();return true}return false}
function timer(){if(state&&!state.done){const n=$('pageTime');if(n)n.textContent=Math.floor(elapsed()/60)+'m '+Math.floor(elapsed()%60)+'s on this page'}}

// Read-aloud uses the cancel token and speed-restart pattern from ReadingVoice.
const narration={rate:.85,token:0,running:false,started:false,index:0,parts:[],utterance:null,target:'story',message:'Ready to listen.',error:false};
const narrationRates=[[.7,'Slow'],[.85,'Steady'],[1,'Normal'],[1.2,'Fast']];
function narrationAvailable(){return 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance==='function'}
function narrationTarget(){if(state?.stage==='math')return 'math';return view==='questions'?'questions':'story'}
function narrationControls(){
return '<div class="narration-bar" role="group" aria-label="Read aloud"><button type="button" id="readAloud" aria-label="Read '+narrationTarget()+' aloud">▶ Read '+narrationTarget()+'</button><button type="button" id="stopAloud" disabled aria-label="Stop reading aloud">■ Stop</button><label class="voice-speed" for="readSpeed">Speed <select id="readSpeed" aria-label="Reading speed">'+narrationRates.map(([rate,label])=>'<option value="'+rate+'" '+(narration.rate===rate?'selected':'')+'>'+label+' ('+rate+'×)</option>').join('')+'</select></label><span class="voice-status" id="voiceStatus" role="status" aria-live="polite"></span></div>';
}
function updateNarration(){
const play=$('readAloud');if(!play)return;
play.textContent=narration.running?'🔊 Reading…':'▶ Read '+narrationTarget();
play.disabled=narration.running||!narrationAvailable();
play.setAttribute('aria-label','Read '+narrationTarget()+' aloud');
$('stopAloud').disabled=!narration.running;
$('readSpeed').value=String(narration.rate);
$('voiceStatus').textContent=narration.message;
play.closest('.narration-bar').dataset.error=String(narration.error);
}
function stopNarration(update=true){
narration.token++;narration.running=false;narration.started=false;narration.utterance=null;
if(narrationAvailable())window.speechSynthesis.cancel();
narration.message='Voice stopped.';narration.error=false;
if(update)updateNarration();
}
function narrationParts(target){
const p=state.p,section=LEVELS[state.level].sections[p];
if(target==='math')return ['Math break '+(p+1)+'. '+MATH_PAGES[p].title,...MATH_PAGES[p].questions.flatMap((q,i)=>['Question '+(i+1)+'. '+q.prompt,q.description,...q.choices.map((choice,j)=>'Choice '+(j+1)+'. '+choice+'.')])];
if(target==='story')return ['Section '+(p+1)+'. '+sectionTitle(state?.level||chosenLevel,p)+'.',...clozeReadAloud(section)];
const parts=['Questions for section '+(p+1)+'.'];
section.mc.forEach((q,i)=>{parts.push('Question '+(i+1)+'. '+q.prompt);q.choices.forEach((choice,j)=>parts.push('Choice '+(j+1)+'. '+choice+'.'))});
parts.push('Question '+(section.mc.length+1)+'. '+matchingInstruction(section));
section.match.rows.forEach(([prompt],i)=>{parts.push('Match '+(i+1)+'. '+prompt+'.');parts.push('Your choices are: '+section.match.options.join('. Or, ')+'.')});
return parts;
}
function speakNarrationPart(token){
if(token!==narration.token||!narration.running)return;
if(narration.index>=narration.parts.length){narration.running=false;narration.utterance=null;narration.message='Finished. Press play to hear it again.';updateNarration();return}
const synth=window.speechSynthesis,u=new window.SpeechSynthesisUtterance(narration.parts[narration.index]);
const voices=synth.getVoices().filter(v=>/^en(?:-|_)/i.test(v.lang));
u.voice=voices.find(v=>v.localService&&/^en-CA/i.test(v.lang))||voices.find(v=>v.localService&&v.default)||voices.find(v=>v.localService)||voices.find(v=>/^en-CA/i.test(v.lang))||voices.find(v=>v.default)||voices[0]||null;
u.lang=u.voice?.lang||'en-CA';u.rate=narration.rate;u.pitch=1;u.volume=1;narration.utterance=u;
u.onstart=()=>{if(token!==narration.token)return;narration.started=true;narration.message='Reading '+narration.target+'.';updateNarration()};
u.onend=()=>{if(token!==narration.token)return;narration.index++;speakNarrationPart(token)};
u.onerror=()=>{if(token!==narration.token)return;stopNarration(false);narration.error=true;narration.message='Voice is unavailable. Try Edge or Chrome with an English voice installed.';updateNarration()};
try{if(synth.paused)synth.resume();synth.speak(u)}catch{u.onerror()}
}
function startNarration(){
if(!state||state.done||!hasNarration(state.level))return;
stopNarration(false);
if(!narrationAvailable()){narration.error=true;narration.message='Read-aloud is unavailable in this browser.';updateNarration();return}
if(view==='picture'){view='story';document.querySelector('.workspace').dataset.view=view;document.querySelectorAll('.view-tabs button[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view))}
narration.target=narrationTarget();narration.parts=narrationParts(narration.target);narration.index=0;narration.running=true;narration.started=false;narration.message='Starting voice…';narration.error=false;
const token=narration.token;navpush('read_aloud',narration.target+'; speed='+narration.rate);updateNarration();speakNarrationPart(token);
setTimeout(()=>{if(token===narration.token&&narration.running&&!narration.started){stopNarration(false);narration.error=true;narration.message='The voice did not start. Check that an English voice is installed, then try again.';updateNarration()}},8000);
}
function changeNarrationSpeed(value){
const rate=Number(value);if(!narrationRates.some(([r])=>r===rate))return;
const reading=narration.running,parts=narration.parts,index=narration.index,target=narration.target;
stopNarration(false);narration.rate=rate;if(state){state.voiceRate=rate;navpush('read_aloud_speed',rate)}
narration.message='Speed: '+narrationRates.find(([r])=>r===rate)[1]+'.';
if(reading){narration.parts=parts;narration.index=index;narration.target=target;narration.running=true;narration.message='Reading '+target+'.';speakNarrationPart(narration.token)}
updateNarration();
}
function bindNarration(){
if(!state||!hasNarration(state.level))return;
narration.message=narrationAvailable()?'Choose play to listen.':'Read-aloud is unavailable in this browser.';narration.error=!narrationAvailable();
$('readAloud').onclick=startNarration;
$('stopAloud').onclick=()=>{stopNarration();navpush('read_aloud_stop')};
$('readSpeed').onchange=e=>changeNarrationSpeed(e.target.value);updateNarration();
}

function landing(){
stopNarration(false);
$('app').innerHTML='<main class="landing"><div class="cover" role="img" aria-label="'+SCENE_ALTS[0]+'"><div class="cover-note"><span class="tag">HIGH PARK · HALLOWEEN NIGHT</span><h2 id="coverHouseCount">'+LEVELS[chosenLevel].houseCount+' houses.<br>Five clues.<br>One tiny mystery.</h2><p>Join Maya, Theo, Noor, and Ben.</p></div></div><div class="landing-body"><div class="brand">A READ · DRAG · FOLLOW THE STORY ACTIVITY</div><h1>The Tiny<br><em>Pumpkin Mystery</em></h1><p class="intro">Read about the Halloween party. Drag words into the story blanks, then answer the questions. Follow the friends as they find the pumpkin keychain.</p><div><div class="level-choices">'+Object.entries(LEVELS).map(([k,l])=>'<button type="button" class="level-choice '+(k===chosenLevel?'active':'')+'" data-level="'+k+'" aria-pressed="'+(k===chosenLevel)+'"><b>'+k+'</b><span>'+l.grade+'</span></button>').join('')+'</div><p class="level-desc" id="levelDesc">'+LEVELS[chosenLevel].intro+'</p></div><div class="start-line"><label class="id-field" for="studentId">Class ID<select id="studentId" aria-label="Class ID" required><option value="">Choose a Halloween object…</option>'+HALLOWEEN_IDS.map(id=>'<option value="'+id.replace(/ /g,'-')+'">'+id+'</option>').join('')+'</select></label><div class="start-actions"><button id="startBtn" class="primary">Begin story →</button><button id="startReset" type="button" class="quiet">↻ Reset</button></div></div><div class="rules"><a class="worksheet-entry" href="Halloween-Worksheet-Fun/index.html">🎃 40 Halloween activities + maze fun · Grades 2–3 →</a><strong>Fill the story blanks, then answer the questions.</strong> Read the whole page and fill every blank. Then answer the questions and lock the page. Earlier pages stay locked.</div><p class="status" id="startStatus" role="status"></p><div class="landing-footer"><span id="totalMarks">8 story pages + 7 math breaks · '+assessmentMaximum(chosenLevel)+' question marks · cloze words recorded separately</span><span>Progress saves on this device</span></div></div></main>';
document.querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>{chosenLevel=b.dataset.level;document.querySelectorAll('[data-level]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',x===b)});$('levelDesc').textContent=LEVELS[chosenLevel].intro;$('coverHouseCount').innerHTML=LEVELS[chosenLevel].houseCount+' houses.<br>Eight story pages.<br>Words to discover.';$('totalMarks').textContent='8 story pages + 7 math breaks · '+assessmentMaximum(chosenLevel)+' question marks · cloze words recorded separately'});
bindTeacherVoice();$('startBtn').onclick=start;$('startReset').onclick=requestReset;$('studentId').onkeydown=e=>{if(e.key==='Enter')start()};
if(attemptStorage.mode!=='local')document.querySelector('.landing-footer span:last-child').textContent=attemptStorage.mode==='session'?'Progress saves in this tab':'Keep this tab open until finished';
}
function start(){
const id=$('studentId').value.trim();
if(!HALLOWEEN_IDS.some(name=>name.replace(/ /g,'-')===id)){$('startStatus').textContent='Choose your Halloween object from the Class ID dropdown.';$('studentId').focus();return}
state=load(chosenLevel,id)||{version:chosenLevel==='A'?4:2,sid:id,level:chosenLevel,p:0,startT:now(),done:false,answers:{},pageTimes:Array(storyCount(chosenLevel)).fill(0),mathTimes:Array(MATH_PAGES.length).fill(0),mathAnswers:{},stage:'story',locked:[],events:[],submittedAt:null};
if(state.storyLayoutVersion!==2){state.readParts={};state.storyLayoutVersion=2}
narration.rate=narrationRates.some(([r])=>r===state.voiceRate)?state.voiceRate:(LEVELS[state.level].defaultRate||.85);pageStart=state.done?null:Date.now();view=initialView();store();navpush(state.done?'reopen_receipt':'start_or_resume');render();
}
function requestReset(){
const id=state?state.sid:$('studentId').value.trim(),level=state?state.level:chosenLevel;
if(!id){teacherVoiceEnabled=false;state=null;pageStart=null;selectedHouse=1;soundOn=false;landing();$('startStatus').textContent='Ready for a new student. Choose a Halloween object.';return}
resetTarget={level,id,nextStudent:!!state?.done};
$('resetTitle').textContent=resetTarget.nextStudent?'Ready for the next student?':'Reset this attempt?';
$('confirmReset').textContent=resetTarget.nextStudent?'Clear for next student':'↻ Reset attempt';
$('resetText').textContent=resetTarget.nextStudent?'Download the result file first if you need it. This clears '+id.replace(/-/g,' ')+'’s saved answers and section locks in this browser, then opens a blank Class ID dropdown for the next student.':'Reset '+id.replace(/-/g,' ')+' in Level '+level+'? This clears its saved answers and section locks in this browser. You can then use the same object to begin again at Section 1.';
$('resetStatus').textContent='';$('resetDialog').showModal();
}
function resetAttempt(){teacherVoiceEnabled=false;selectedClozeWord=null;clozeScope='';selectedMathChoice=null;mathScope='';selectedReadingChoice=null;readingScope='';storyReference.scope='';
stopNarration();
if(!resetTarget)return;const {level,id,nextStudent}=resetTarget;
attemptStorage.removeItem(storageKey(level,id));
teacherReport.unlocked=false;teacherReport.pages=null;teacherReport.scope='';$('parentReportDialog')?.close();$('parentPrintReport')?.remove();state=null;pageStart=null;selectedHouse=1;soundOn=false;narration.rate=.85;chosenLevel=level;view='story';resetTarget=null;$('resetDialog').close();landing();$('studentId').value=nextStudent?'':id;$('startStatus').textContent=nextStudent?'Ready for the next student. Choose a Halloween object to begin.':'Reset complete. '+id.replace(/-/g,' ')+' can begin again at Section 1.';
}
$('cancelReset').onclick=()=>$('resetDialog').close();$('confirmReset').onclick=resetAttempt;
function initialView(){return 'story'}
function scene(p,cls='scene'){
const index=storyArtPage(state?.level||chosenLevel,p);
return '<div class="'+cls+'" style="--pos:'+(index%3*50)+'% '+(index<3?'0':'100')+'%" role="img" aria-label="'+escapeHTML(SCENE_ALTS[index])+'"><svg class="scene-art" xmlns="http://www.w3.org/2000/svg" viewBox="'+(index%3)+' '+(Math.floor(index/3)*1.5)+' 1 1.5" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><defs><clipPath id="sceneCrop"><rect x="'+(index%3)+'" y="'+(Math.floor(index/3)*1.5)+'" width="1" height="1.5"/></clipPath></defs><image clip-path="url(#sceneCrop)" href="'+art+'" width="3" height="3"/></svg><span class="scene-label">THE TINY PUMPKIN STORY</span><span class="scene-caption"><small>STORY '+(p+1)+'</small><b>'+sectionTitle(state?.level||chosenLevel,p)+'</b></span></div>';
}

function render(){
stopNarration(false);
if(!state){landing();return}if(state.done){showFinished();return}if(state.stage==='math'){renderMath();return}
const p=state.p,s=LEVELS[state.level].sections[p],a=state.answers[p]||{};
$('app').innerHTML='<main class="shell grade-'+state.level+'"><header class="topbar"><div class="wordmark">The Tiny Pumpkin Mystery</div><div class="top-info"><span class="badge id-badge">'+escapeHTML(state.sid)+' · '+state.level+'</span><span class="badge">Story '+(p+1)+' / '+storyCount()+'</span><button id="openMap">Street map</button><button id="openClues">🔍 Clues '+collectedClues()+' / 5</button></div></header><div class="progress" role="progressbar" aria-label="Sections completed" aria-valuemin="0" aria-valuemax="'+studentPageCount()+'" aria-valuenow="'+studentPageIndex()+'"><i style="width:'+studentPageIndex()/studentPageCount()*100+'%"></i></div><nav class="view-tabs" aria-label="Current section tools"><button data-view="picture" aria-label="View this page picture" class="'+(view==='picture'?'active':'')+'">Picture</button><button data-view="story" aria-label="Read the story" class="'+(view==='story'?'active':'')+'">Story</button><button data-view="questions" aria-label="Answer questions" class="'+(view==='questions'?'active':'')+'">Questions</button></nav><div class="workspace" data-view="'+view+'"><article class="read-card">'+scene(p)+'<div class="story"><span class="eyebrow">SECTION '+String(p+1).padStart(2,'0')+'</span><h1 tabindex="-1" id="sectionTitle">'+sectionTitle(state?.level||chosenLevel,p)+'</h1><div class="cloze-panel" id="clozePanel" aria-label="Drag words into the story">'+clozeMarkup(s)+'</div></div></article><aside id="textReferenceSide" class="question-reference reference-content grade-'+state.level+'" aria-label="Story text for these questions"></aside>'+readingAssessmentMarkup(s,a)+'</div><footer class="bottom-bar '+(hasNarration(state.level)?'with-narration':'')+'">'+(hasNarration(state.level)?narrationControls():'')+'<span id="saveStatus">Saved on this device · Earlier sections lock when you continue</span><span id="pageTime"></span></footer></main>';
document.querySelectorAll('[data-answer]').forEach(el=>el.onchange=()=>{if(syncLatest())return;state.answers[p]||={};state.answers[p][el.dataset.answer]=el.value;navpush('answer_changed',el.dataset.answer);$('answerStatus').textContent=countAnswers(state.answers[p])+' / '+sectionMaximum(state.level,state.p)+' answered'});
document.querySelectorAll('.view-tabs button[data-view]').forEach(b=>b.onclick=()=>{stopNarration(false);view=b.dataset.view;document.querySelector('.workspace').dataset.view=view;document.querySelectorAll('.view-tabs button[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===view));narration.message='Choose play to listen.';updateNarration();navpush('view_tool',view);bindStoryReference();if(view==='story'){clozeCompact=false;redrawCloze()}});
$('nextBtn').onclick=requestNext;$('openMap').onclick=openMap;$('openClues').onclick=openClues;bindNarration();bindCloze();bindReadingAnswers();bindStoryReference();bindTeacherVoice();fitClozePanel();timer();updateStorageNotice();
}
function countAnswers(a){return answerKeys(LEVELS[state.level].sections[state.p]).filter(k=>a[k]!==undefined&&a[k]!=='').length}
function requestNext(){
stopNarration();
if(state.stage==='math'){if(syncLatest())return;const count=Object.keys(state.mathAnswers?.[state.p]||{}).length;$('lockText').textContent='You have answered '+count+' of 3 maths questions. This maths page and its answers will lock. Unanswered questions receive 0 marks.';$('confirmNext').textContent='🔒 Lock maths & continue →';$('lockDialog').showModal();return}
if(syncLatest())return;
const a=state.answers[state.p]||{},answered=countAnswers(a),maximum=sectionMaximum(state.level,state.p);
const wordsFilled=clozeCount(LEVELS[state.level].sections[state.p],a),wordsTotal=LEVELS[state.level].sections[state.p].cloze.blanks.length;
const wordWarning='Story blanks: '+wordsFilled+' of '+wordsTotal+' filled. ';
const warning=answered<maximum?'You have answered '+answered+' of '+maximum+' items. Unanswered items will receive 0 marks. ':'All '+maximum+' items have an answer. ';
$('lockText').textContent=wordWarning+warning+(state.p===storyCount(state.level)-1?'Submitting locks your final answers. Your result file will be ready to download.':'Section '+(state.p+1)+' and its answers will be locked. You will not be able to read or change this section again.');
$('confirmNext').textContent=state.p===storyCount(state.level)-1?'🔒 Submit assessment':'🔒 Lock & continue →';
$('lockDialog').showModal();
}

function next(){
if(syncLatest()){$('lockDialog').close();return}
savePage();state.locked.push({kind:state.stage||'story',section:state.p+1,at:now()});state.events.push({action:state.stage==='math'?'math_locked':'section_locked',section:state.p+1,time:now(),detail:''});
if(state.stage==='math'){state.p++;state.stage='story'}else if(state.p===storyCount()-1){state.done=true;state.submittedAt=now();pageStart=null}else{state.stage='math';state.mathView=0}
if(!state.done)pageStart=Date.now();store();$('lockDialog').close();view=initialView();render();$('sectionTitle')?.focus();
}
$('keepWorking').onclick=()=>$('lockDialog').close();$('confirmNext').onclick=next;
function openClues(){
stopNarration();
$('clueList').innerHTML=(LEVELS[state.level].clues||CLUES).slice(0,collectedClues()).map(c=>'<li class="clue-item">'+escapeHTML(c)+'</li>').join('');navpush('open_clues');$('clueDialog').showModal();
}
$('closeClues').onclick=()=>$('clueDialog').close();
function activeHouses(level=state?.level||chosenLevel){
return LEVELS[level].houseProfiles.map((profile,i)=>({...HOUSES.find(h=>h.n===profile),n:i+1,side:i%2?'East':'West',artIndex:profile-1}));
}
function drawHouse(h){
const brick=['#be715a','#bb835b','#c08d75','#b96d5d','#aa795d'][(h.n-1)%5];
const light=lamps[h.lamp],g='house'+h.n;
const pumpkins=Array.from({length:h.pumpkins},(_,i)=>'<g transform="translate('+(17+i*(h.pumpkins>1?Math.min(16,44/(h.pumpkins-1)):0))+' 95)"><ellipse rx="6" ry="5" fill="#ef8b2c"/><path d="M-2-1l1-2 1 2m2 0l1-2 1 2m-6 2q2 3 5 0" stroke="#624229" fill="none" stroke-width="1"/><path d="M0-5l1-3" stroke="#6d6a3e" stroke-width="2"/></g>').join('');
return '<svg class="drawn-house" viewBox="0 0 180 110" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="'+g+'wall" x2="0" y2="1"><stop stop-color="#ecc3a5"/><stop offset="1" stop-color="'+brick+'"/></linearGradient><linearGradient id="'+g+'roof" x2="0" y2="1"><stop stop-color="#69728e"/><stop offset="1" stop-color="#30384f"/></linearGradient></defs><ellipse cx="90" cy="101" rx="79" ry="8" fill="#9caa80"/><path d="M31 41h117v54H31z" fill="url(#'+g+'wall)" stroke="#945c51" stroke-width="2"/><path d="M31 53h117M31 65h117M31 77h117M31 89h117" stroke="#e5b297" stroke-width="1" opacity=".65"/><path d="M26 44L89 6l65 38-7 4-58-31-56 31z" fill="url(#'+g+'roof)" stroke="#333b51" stroke-width="2"/><path d="M48 30V14h13v9" fill="#9b6657" stroke="#794d48" stroke-width="2"/><path d="M29 45L89 12l62 33" fill="none" stroke="#f5dfbf" stroke-width="3"/><rect x="72" y="27" width="35" height="23" rx="7" fill="#fff1cc" stroke="#7f5848" stroke-width="1.5"/><text x="89.5" y="44" text-anchor="middle" font-family="Arial,sans-serif" font-size="21" font-weight="bold" fill="#3b3144">'+h.n+'</text><rect x="41" y="55" width="22" height="24" rx="2" fill="#ffd986" stroke="#fff0d0" stroke-width="3"/><path d="M52 55v24M41 67h22" stroke="#b27b60" stroke-width="2"/><rect x="116" y="55" width="22" height="24" rx="2" fill="#ffd986" stroke="#fff0d0" stroke-width="3"/><path d="M127 55v24M116 67h22" stroke="#b27b60" stroke-width="2"/><rect x="78" y="57" width="25" height="38" rx="3" fill="#51405a" stroke="#f8dfbd" stroke-width="3"/><rect x="83" y="62" width="15" height="16" rx="1" fill="#f5cd82"/><circle cx="97" cy="86" r="1.8" fill="#f4d79b"/><circle cx="110" cy="68" r="10" fill="'+light+'" opacity=".2"/><rect x="106" y="61" width="8" height="14" rx="2" fill="'+light+'" stroke="#4e4050" stroke-width="1.5"/><path d="M76 96h29l7 13H68z" fill="#d3c7b1"/><path d="M10 90h58v8H10" fill="#c6bdac" stroke="#aca392"/>'+pumpkins+(h.mode==='motion'?'<rect x="80" y="100" width="20" height="5" rx="1" fill="#343342"/>':'')+'</svg>';
}
function openMap(){
stopNarration();
const houses=activeHouses();if(!houses.some(h=>h.n===selectedHouse))selectedHouse=1;
$('mapTitle').textContent='Party street — '+houses.length+' houses';$('houseGrid').style.gridTemplateRows='repeat('+(houses.length/2)+',minmax(0,1fr))';
$('houseGrid').innerHTML=houses.map(h=>'<button class="house '+(selectedHouse===h.n?'chosen':'')+'" data-house="'+h.n+'" style="grid-column:'+(h.side==='West'?1:3)+';grid-row:'+Math.ceil(h.n/2)+'" aria-label="Explore House '+h.n+', '+h.side+' side">'+drawHouse(h)+'<span class="house-caption"><b>'+h.n+'</b><small><i class="lamp-dot" style="background:'+lamps[h.lamp]+'"></i>'+h.lamp+' · '+h.pumpkins+' pumpkin'+(h.pumpkins===1?'':'s')+'</small></span></button>').join('');
document.querySelectorAll('[data-house]').forEach(b=>b.onclick=()=>{selectedHouse=Number(b.dataset.house);document.querySelectorAll('[data-house]').forEach(x=>x.classList.toggle('chosen',x===b));navpush('explore_house',selectedHouse);renderYard()});
renderYard();navpush('open_map');$('mapDialog').showModal();
}
function renderYard(){
const h=activeHouses().find(h=>h.n===selectedHouse);
$('yardDetail').innerHTML='<div class="yard-visual" id="yardVisual" style="background-position:'+((h.artIndex%2)*100)+'% '+(Math.floor(h.artIndex/2)*25)+'%" role="img" aria-label="Illustrated lawn at House '+h.n+'"></div><h3>House '+h.n+' · '+h.prop+' lawn</h3><dl><dt>Side</dt><dd>'+h.side+'</dd><dt>Porch light</dt><dd>'+h.lamp+'</dd><dt>Low wall</dt><dd>'+h.pumpkins+' carved pumpkin'+(h.pumpkins===1?'':'s')+'</dd><dt>Decoration</dt><dd>'+h.prop+(h.prop==='Owl'?' · perch in the lawn':'')+'</dd><dt>Container</dt><dd>'+escapeHTML(h.container?(h.container+' beneath perch'):'None')+'</dd></dl><button id="activateYard" class="primary">'+h.action+' →</button><p id="yardResponse" class="yard-note" role="status">Try the lawn feature to see what happens.</p><label class="sound-toggle muted"><input type="checkbox" id="soundToggle" '+(soundOn?'checked':'')+'> Optional sound</label>';
$('soundToggle').onchange=e=>{soundOn=e.target.checked};
$('activateYard').onclick=()=>{navpush('activate_house',h.n+': '+h.action);$('yardResponse').textContent=h.reaction;const v=$('yardVisual');v.classList.remove('activated');void v.offsetWidth;v.classList.add('activated');if(soundOn)playSound(h)};
}
function playSound(h){
try{audioContext||=new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();const base=h.prop==='Owl'?260:h.prop==='Cat'?500:350;[0,.28].forEach((d,i)=>{const o=audioContext.createOscillator(),g=audioContext.createGain();o.type='sine';o.frequency.setValueAtTime(base+i*40,audioContext.currentTime+d);g.gain.setValueAtTime(0,audioContext.currentTime+d);g.gain.linearRampToValueAtTime(.1,audioContext.currentTime+d+.03);g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+d+.25);o.connect(g).connect(audioContext.destination);o.start(audioContext.currentTime+d);o.stop(audioContext.currentTime+d+.27)})}catch{}
}
$('closeMap').onclick=()=>$('mapDialog').close();
function results(){
const rows=[];let score=0;
LEVELS[state.level].sections.forEach((s,p)=>{const a=state.answers[p]||{};s.mc.forEach((q,i)=>{const response=a['m'+i]===undefined?'':q.choices[Number(a['m'+i])],correct=q.choices[q.answer],mark=response===correct?1:0;score+=mark;rows.push({section:p+1,item:'Q'+(i+1),type:'Multiple choice',skill:q.skill,prompt:q.prompt,options:q.choices.slice(),response,correct,mark,seconds:Math.round(state.pageTimes[p])})});s.match.rows.forEach(([prompt,correct],i)=>{const response=a['t'+i]||'',mark=response===correct?1:0;score+=mark;rows.push({section:p+1,item:'M'+(i+1),type:'Matching',skill:s.match.skill,prompt,options:s.match.options.slice(),instruction:matchingInstruction(s),response,correct,mark,seconds:Math.round(state.pageTimes[p])})})});
const clozeRows=clozeReportRows(state.level,state.answers,state.pageTimes),clozeScore=clozeRows.reduce((sum,row)=>sum+row.mark,0),mathRows=mathReportRows(state),mathScore=mathRows.reduce((sum,row)=>sum+row.mark,0);
return {activity:'Cloze story and Halloween maths',mathRows,mathScore,mathTotal:mathRows.length,clozeRows,clozeScore,clozeTotal:clozeRows.length,student_id:state.sid,level:state.level,grade:LEVELS[state.level].grade,started_at:state.startT,submitted_at:state.submittedAt,score,total:rows.length,percent:Math.round(score/rows.length*100),rows,pages:Array.from({length:storyCount(state.level)},(_,p)=>({section:p+1,title:sectionTitle(state?.level||chosenLevel,p),score:rows.filter(x=>x.section===p+1).reduce((n,r)=>n+r.mark,0),maximum:sectionMaximum(state.level,p),seconds:Math.round(state.pageTimes[p])})),events:state.events};
}
function showFinished(){teacherHandoff(results())}
function downloadFile(content,mime,suffix,identity=state){const u=URL.createObjectURL(new Blob([content],{type:mime})),a=document.createElement('a');a.href=u;a.download='Pumpkin_'+identity.level+'_'+(identity.student_id||identity.sid)+'_'+suffix;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1500)}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"'}
function downloadCSV(r){
const head=['Student ID','Level','Section','Item','Type','Skill','Question','Response to paste','Correct response','Marks','Maximum','Section seconds'];
const lines=[...r.rows,...(r.clozeRows||[]),...(r.mathRows||[])].map(x=>[r.student_id,r.level,x.section,x.item,x.type,x.skill,x.prompt,x.response,x.correct,x.mark,1,x.seconds]);
downloadFile('\ufeff'+[head,...lines].map(row=>row.map(csvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8','results.csv');$('downloadStatus').textContent='CSV downloaded. Give the file to your teacher.';
}
/* Small dependency-free ZIP writer, retaining the Artifact Tool-authored workbook template. */
const xmlEscape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function hasNarration(level=state?.level||chosenLevel){return teacherVoiceEnabled===true&&!!LEVELS[level]}
function sectionTitle(level,p){return (LEVELS[level].titles||TITLES)[p]}
function matchingTitle(s){return s.match.rows.length===1?'Make a match':'Match each pair'}
function matchingHelp(s){return s.match.rows.length===s.match.options.length?'Drag each answer to a pad. You can move it again.':'Drag one answer to the pad.'}
function matchingInstruction(s){return matchingTitle(s)+'. '+matchingHelp(s)}
function sectionMaximum(level,p){const s=LEVELS[level].sections[p];return s.mc.length+s.match.rows.length}
function assessmentMaximum(level){return LEVELS[level].sections.reduce((n,s)=>n+s.mc.length+s.match.rows.length,0)}
function answerKeys(s){return [...s.mc.map((_,i)=>'m'+i),...s.match.rows.map((_,i)=>'t'+i)]}
function crc32(a){let c=-1;for(const b of a){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^-1)>>>0}
function zipStored(files){const enc=new TextEncoder(),parts=[],central=[];let offset=0;const put=(size,fn)=>{const a=new Uint8Array(size);fn(new DataView(a.buffer));return a};
for(const [name,value] of Object.entries(files)){const n=enc.encode(name),a=typeof value==='string'?enc.encode(value):value,c=crc32(a),h=put(30,v=>{v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint32(14,c,true);v.setUint32(18,a.length,true);v.setUint32(22,a.length,true);v.setUint16(26,n.length,true)});parts.push(h,n,a);central.push(put(46,v=>{v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint32(16,c,true);v.setUint32(20,a.length,true);v.setUint32(24,a.length,true);v.setUint16(28,n.length,true);v.setUint32(42,offset,true)}),n);offset+=30+n.length+a.length}
const count=Object.keys(files).length,cs=central.reduce((n,a)=>n+a.length,0),end=put(22,v=>{v.setUint32(0,0x06054b50,true);v.setUint16(8,count,true);v.setUint16(10,count,true);v.setUint32(12,cs,true);v.setUint32(16,offset,true)});return new Blob([...parts,...central,end],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})}
function excelCell(v){return typeof v==='number'?'<c><v>'+v+'</v></c>':'<c t="inlineStr"><is><t xml:space="preserve">'+xmlEscape(v)+'</t></is></c>'}
function replaceSheetData(xml,rows,settings={}){
let data='<sheetData>';
rows.forEach((row,i)=>{
const styleRow=settings[i]?.template||(i>=26?27:i+1),original=new RegExp('<row\\b[^>]*\\br="'+(i+1)+'"[^>]*>').exec(xml),fallback=new RegExp('<row\\b[^>]*\\br="'+styleRow+'"[^>]*>').exec(xml);
let tag=(settings[i]?.template?fallback:original)?.[0]||fallback?.[0]||'<row r="'+(i+1)+'">';tag=tag.replace(/\br="\d+"/,'r="'+(i+1)+'"');
if(settings[i]?.height){tag=tag.replace(/\s(?:ht|customHeight)="[^"]*"/g,'').replace('>',' ht="'+settings[i].height+'" customHeight="1">')}
data+=tag+row.map((value,j)=>{let n=j+1,col='';while(n){col=String.fromCharCode(65+(n-1)%26)+col;n=Math.floor((n-1)/26)}
const reference=col+(settings[i]?.template?styleRow:i+1),old=new RegExp('<c\\b[^>]*\\br="'+reference+'"[^>]*>').exec(xml)||new RegExp('<c\\b[^>]*\\br="'+col+styleRow+'"[^>]*>').exec(xml),style=old?.[0].match(/\bs="(\d+)"/)?.[1];
return excelCell(value).replace('<c','<c r="'+col+(i+1)+'"'+(style?' s="'+style+'"':''))}).join('')+'</row>';
});
return xml.replace(/<sheetData[\s\S]*?<\/sheetData>/,data+'</sheetData>').replace(/<dimension ref="([A-Z]+\d+):([A-Z]+)\d+"\s*\/>/,'<dimension ref="$1:$2'+rows.length+'"/>');
}
function optionsText(row){
return row.options.map((c,i)=>String.fromCharCode(65+i)+'. '+c).join(row.options.length>5?'   ':'\n');
}
function createExcelFiles(r){return extendedExcelFiles(r)}
async function fillReportImages(files){
const source=new Image();source.src=art;await source.decode();
const width=Math.round(source.naturalWidth/3),height=Math.round(source.naturalHeight/2);
for(const [path,value]of Object.entries(files)){
if(value&&typeof value==='object'&&value.page){
const index=storyArtPage(state.level,value.page-1),canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
canvas.getContext('2d').drawImage(source,(index%3)*width,Math.floor(index/3)*height,width,height,0,0,width,height);
const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Could not prepare page picture')),'image/png'));
files[path]=new Uint8Array(await blob.arrayBuffer());
}else if(value&&typeof value==='object'&&value.base64){files[path]=Uint8Array.from(atob(value.base64),c=>c.charCodeAt(0))}
}
}

async function downloadXLSX(r){
const button=$('downloadXlsx'),status=$('downloadStatus');
try{
if(button){button.disabled=true;button.textContent='Preparing Excel…'}if(status)status.textContent='Adding story text, page pictures, questions, options, and your answers…';
const files=createExcelFiles(r);await fillReportImages(files);
downloadFile(zipStored(files),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','results.xlsx',r);
if(status)status.textContent='Full illustrated Excel report downloaded. Give the file to your teacher.';
}catch(e){if(status)status.textContent='Excel download could not finish. Use CSV or Save backup; your answers are still saved.';console.error(e)}
finally{if(button){button.disabled=false;button.textContent='Download Excel results'}}
}

window.addEventListener('resize',()=>{if(state&&!state.done&&state.stage!=='math'){clozeCompact=false;if(view!=='questions')redrawCloze();else{storyReference.side.compact=false;mountStoryReference('side')}}if(state&&!state.done&&view==='picture'&&!window.matchMedia('(max-width:600px)').matches){view='story';render()}});
window.addEventListener('pagehide',()=>{savePage();stopNarration(false)});window.addEventListener('beforeunload',()=>{savePage();stopNarration(false)});window.addEventListener('focus',()=>{syncLatest()});
window.addEventListener('storage',e=>{if(attemptStorage.mode==='local'&&state&&e.key===storageKey()){if(e.newValue===null){const id=state.sid;chosenLevel=state.level;state=null;pageStart=null;landing();$('studentId').value=id;$('startStatus').textContent='This attempt was reset. You can begin again at Section 1.'}else syncLatest()}});
window.addEventListener('popstate',()=>{syncLatest();if(state)render()});
document.addEventListener('visibilitychange',()=>{if(document.hidden){savePage();stopNarration()}});
setInterval(()=>{if(!document.hidden){timer();savePage()}},10000);setInterval(timer,1000);
landing();





