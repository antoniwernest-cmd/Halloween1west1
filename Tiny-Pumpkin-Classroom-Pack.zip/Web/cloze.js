/* Shared cloze controls: pointer dragging, touch placement and keyboard access. */
let selectedClozeWord=null,clozeScope='',clozeDrag=null,clozeCompact=false,clozeEventsBound=false,clozeClickGuard=null;
function clozeChoice(section,token){return section.cloze?.bank.find(word=>word.id===token)}
function clozeCount(section,answers={}){return (section.cloze?.blanks||[]).filter(blank=>clozeChoice(section,answers[blank.id])).length}
function clozePart(section){return Math.min(Math.max(0,state.readParts?.[state.p]||0),section.cloze.parts.length-1)}
function clozeBlankButton(blank,answers,pad=false){const choice=clozeChoice(LEVELS[state.level].sections[state.p],answers[blank.id]),number=Number(blank.id.slice(1))+1;return '<button type="button" draggable="'+!!choice+'" class="cloze-blank '+(choice?'filled':'')+'" data-blank="'+blank.id+'" data-token="'+(choice?.id||'')+'" aria-label="'+(pad?'Answer pad ':'Blank ')+number+': '+escapeHTML(choice?.word||'empty')+'">'+(pad?'<small>'+number+'</small><span>'+childText(choice?.word||'____',state.level)+'</span>':childText(choice?.word||number+'. ____',state.level))+'</button>'}
function clozeMarkup(section){
const scope=state.level+'|'+state.sid+'|'+state.p;if(scope!==clozeScope){selectedClozeWord=null;clozeScope=scope;clozeCompact=false}
const answers=state.answers[state.p]||{},index=clozePart(section),parts=section.cloze.parts;
const renderPart=text=>text.split(/(\{\{c\d+\}\})/).map(piece=>{
const id=/^\{\{(c\d+)\}\}$/.exec(piece)?.[1];if(!id)return childText(piece,state.level);
const blank=section.cloze.blanks.find(item=>item.id===id),choice=clozeChoice(section,answers[id]),number=Number(id.slice(1))+1;
if(clozeCompact)return '<span class="cloze-drop-ref" data-blank="'+id+'">['+number+'] '+childText(choice?.word||'____',state.level)+'</span>';
return clozeBlankButton(blank,answers);
}).join('');
const passage=clozeCompact?parts[index].split('\n\n').map(text=>'<p>'+renderPart(text)+'</p>').join(''):innerWidth>=950&&section.cloze.columns?.length===2?section.cloze.columns.map(text=>'<div class="cloze-column"><p>'+renderPart(text)+'</p></div>').join(''):section.cloze.paragraphs.map(text=>'<p>'+renderPart(text)+'</p>').join('');
const used=new Set(section.cloze.blanks.map(blank=>answers[blank.id]).filter(Boolean));
return '<div class="cloze-part-tools">'+(clozeCompact?'<button type="button" data-cloze-part="-1" aria-label="Previous text on this story page" '+(index===0?'disabled':'')+'>←</button><span>Same story page · Text '+(index+1)+' / '+parts.length+'</span><button type="button" data-cloze-part="1" aria-label="More text on this story page" '+(index===parts.length-1?'disabled':'')+'>→</button>':'<span>Read the whole page and fill all '+section.cloze.blanks.length+' blanks.</span>')+'</div><div class="story-text cloze-passage '+(clozeCompact?'':'full-passage')+'" aria-label="Cloze story">'+passage+'</div><div class="cloze-bank '+(clozeCompact?'with-pads':'')+'">'+(clozeCompact?'<div class="cloze-padboard" style="--pad-count:'+section.cloze.blanks.length+'" aria-label="All story blanks">'+section.cloze.blanks.map(blank=>clozeBlankButton(blank,answers,true)).join('')+'</div>':'')+'<div class="cloze-bank-heading"><b>Word bank</b><span>'+clozeCount(section,answers)+' / '+section.cloze.blanks.length+' words filled</span></div><div class="cloze-words">'+section.cloze.bank.map(word=>'<button type="button" draggable="true" class="cloze-word '+(used.has(word.id)?'placed ':'')+(selectedClozeWord===word.id?'selected':'')+'" data-token="'+word.id+'" aria-label="Word '+escapeHTML(word.word)+'" aria-pressed="'+(selectedClozeWord===word.id)+'">'+childText(word.word,state.level)+'</button>').join('')+'</div><p class="cloze-help" role="status">'+(selectedClozeWord?'Choose a blank for “'+escapeHTML(clozeChoice(section,selectedClozeWord)?.word||'')+'”.':'Drag a word to a numbered blank. You can move it again, or tap a word and then a blank.')+'</p></div>';
}
function fitClozePanel(){
const panel=$('clozePanel');if(!panel||!panel.clientWidth||!panel.clientHeight)return;const passage=panel.querySelector('.cloze-passage'),bank=panel.querySelector('.cloze-bank'),level=state.level;
const minimum=clozeCompact?16:level==='Pre-A'?21:level==='A'?(innerWidth<650?18.5:22):innerHeight<650?16.5:18;
let size=parseFloat(getComputedStyle(passage).fontSize);const over=()=>passage.getBoundingClientRect().bottom+3>bank.getBoundingClientRect().top||panel.scrollHeight>panel.clientHeight+2;
while(over()&&size>minimum){size=Math.max(minimum,size-.5);passage.style.fontSize=size+'px'}
if(over()&&!clozeCompact&&level!=='A'&&level!=='Pre-A'&&innerWidth<900){clozeCompact=true;redrawCloze();return}
if(over()){passage.style.lineHeight='1.24';passage.style.setProperty('--sentence-gap','7px');while(over()&&size>16){size-=.5;passage.style.fontSize=size+'px'}}
panel.dataset.fullStory=String(!clozeCompact);panel.dataset.storyBlankCount=String(LEVELS[level].sections[state.p].cloze.blanks.length);
}
function redrawCloze(focusId){
const panel=$('clozePanel');if(!panel||!state||state.done)return;
panel.innerHTML=clozeMarkup(LEVELS[state.level].sections[state.p]);bindCloze();fitClozePanel();
if(focusId)panel.querySelector('.cloze-blank[data-blank="'+focusId+'"]')?.focus({preventScroll:true});
}
function placeCloze(blankId,token){
if(!state||state.done||state.stage==='math'||syncLatest())return;const section=LEVELS[state.level].sections[state.p];
if(!section.cloze.blanks.some(blank=>blank.id===blankId)||!clozeChoice(section,token))return;
const answers=state.answers[state.p]||=( {} ),source=section.cloze.blanks.find(blank=>answers[blank.id]===token),previous=answers[blankId];
if(source&&source.id!==blankId){if(previous)answers[source.id]=previous;else delete answers[source.id]}
answers[blankId]=token;selectedClozeWord=null;navpush('cloze_changed',blankId);redrawCloze(blankId);const help=$('clozePanel')?.querySelector('.cloze-help');if(help)help.textContent='“'+clozeChoice(section,token).word+'” placed. You can drag it again.';return true;
}
function clearCloze(blankId){
if(!state||state.done||state.stage==='math'||syncLatest())return;delete (state.answers[state.p]||{})[blankId];selectedClozeWord=null;navpush('cloze_cleared',blankId);redrawCloze(blankId);return true;
}
function clickCloze(button){
stopNarration();const blankId=button.dataset.blank;
if(blankId){if(selectedClozeWord)placeCloze(blankId,selectedClozeWord);else if(button.dataset.token)clearCloze(blankId)}
else{selectedClozeWord=selectedClozeWord===button.dataset.token?null:button.dataset.token;redrawCloze()}
}
function finishClozeDrag(){
document.querySelectorAll('.cloze-drop-ready').forEach(el=>el.classList.remove('cloze-drop-ready'));
document.querySelectorAll('.cloze-source-dragging').forEach(el=>el.classList.remove('cloze-source-dragging'));
document.documentElement.classList.remove('cloze-drag-active');document.querySelector('.cloze-story-ghost')?.remove();clozeDrag=null;
}
function clozeGestureScope(){return state.level+'|'+state.sid+'|'+state.p}
function validClozeGesture(drag=clozeDrag){return !!(drag&&state&&!state.done&&state.stage!=='math'&&drag.scope===clozeGestureScope()&&clozeChoice(LEVELS[state.level].sections[state.p],drag.token))}
function clozeDropAt(x,y,fallback){
const panel=$('clozePanel');if(!panel)return {};const hit=document.elementFromPoint(x,y),direct=fallback?.closest?.('.cloze-blank,.cloze-drop-ref')||hit?.closest?.('.cloze-blank,.cloze-drop-ref');
if(direct&&panel.contains(direct))return {blank:direct};const bank=fallback?.closest?.('.cloze-bank')||hit?.closest?.('.cloze-bank');if(bank&&panel.contains(bank))return {bank};
// A small margin around each visible blank makes it easier to release a word.
let nearest=null,distance=Infinity;panel.querySelectorAll('.cloze-blank,.cloze-drop-ref').forEach(blank=>{const r=blank.getBoundingClientRect();if(!r.width||!r.height||x<r.left-12||x>r.right+12||y<r.top-12||y>r.bottom+12)return;const d=Math.hypot(x-(r.left+r.right)/2,y-(r.top+r.bottom)/2);if(d<distance){nearest=blank;distance=d}});return nearest?{blank:nearest}:{};
}
function highlightClozeDrop(target){document.querySelectorAll('.cloze-drop-ready').forEach(el=>el.classList.remove('cloze-drop-ready'));target.blank?.classList.add('cloze-drop-ready')}
function beginClozeGesture(button,e,native=false){
if(!state||state.done||state.stage==='math')return false;const token=button.dataset.token;if(!token)return false;
clozeDrag={button,token,blank:button.dataset.blank,scope:clozeGestureScope(),x:e.clientX,y:e.clientY,pointerType:e.pointerType||'mouse',native,dragging:native};stopNarration();return true;
}
function dropClozeGesture(x,y,fallback,mode){
const drag=clozeDrag,target=clozeDropAt(x,y,fallback),valid=validClozeGesture(drag);finishClozeDrag();if(!valid)return;
clozeClickGuard={x,y,until:Date.now()+350};let applied=false;
if(target.blank)applied=placeCloze(target.blank.dataset.blank,drag.token);else if(drag.blank&&target.bank)applied=clearCloze(drag.blank);
if(applied&&$('clozePanel'))$('clozePanel').dataset.lastDragMode=mode;
}
function moveClozePointer(e){
const drag=clozeDrag;if(!drag||drag.native||!drag.token)return;
if(!drag.dragging&&Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<7)return;
drag.dragging=true;document.documentElement.classList.add('cloze-drag-active');drag.button.classList.add('cloze-source-dragging');let ghost=document.querySelector('.cloze-story-ghost');
if(!ghost){ghost=document.createElement('div');ghost.className='cloze-drag-ghost cloze-story-ghost';ghost.setAttribute('aria-hidden','true');ghost.textContent=clozeChoice(LEVELS[state.level].sections[state.p],drag.token).word;document.body.append(ghost)}
ghost.style.left=e.clientX+'px';ghost.style.top=e.clientY+'px';highlightClozeDrop(clozeDropAt(e.clientX,e.clientY));
}
function endClozePointer(e){
const drag=clozeDrag;if(!drag||drag.native)return;
if(drag.dragging){e.preventDefault();dropClozeGesture(e.clientX,e.clientY,null,'pointer');return}
finishClozeDrag();if(drag.pointerType!=='mouse'){e.preventDefault();clozeClickGuard={x:e.clientX,y:e.clientY,until:Date.now()+350};clickCloze(drag.button)}
}
function bindCloze(){
const panel=$('clozePanel');if(!panel)return;
if(!clozeEventsBound){
clozeEventsBound=true;document.addEventListener('pointermove',moveClozePointer,true);document.addEventListener('pointerup',endClozePointer,true);document.addEventListener('pointercancel',()=>{if(clozeDrag&&!clozeDrag.native)finishClozeDrag()},true);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&clozeDrag)finishClozeDrag()},true);
if(!('PointerEvent' in window)){document.addEventListener('mousemove',moveClozePointer,true);document.addEventListener('mouseup',endClozePointer,true)}
}
panel.querySelectorAll('[data-cloze-part]').forEach(button=>button.onclick=()=>{
finishClozeDrag();
stopNarration();const section=LEVELS[state.level].sections[state.p];state.readParts||={};state.readParts[state.p]=Math.min(section.cloze.parts.length-1,Math.max(0,clozePart(section)+Number(button.dataset.clozePart)));navpush('story_part',state.readParts[state.p]+1);redrawCloze();
});
panel.querySelectorAll('.cloze-word,.cloze-blank').forEach(button=>{
button.onclick=e=>{if(e.detail&&clozeClickGuard&&Date.now()<clozeClickGuard.until&&Math.hypot(e.clientX-clozeClickGuard.x,e.clientY-clozeClickGuard.y)<12)return;clickCloze(button)};
button.onpointerdown=e=>{
if(e.button!==0||e.isPrimary===false)return;
if((e.pointerType||'mouse')!=='mouse'){e.preventDefault();try{button.setPointerCapture(e.pointerId)}catch{}}
if(!beginClozeGesture(button,e)){clozeDrag={button,token:'',blank:button.dataset.blank,scope:clozeGestureScope(),x:e.clientX,y:e.clientY,pointerType:e.pointerType||'mouse',native:false,dragging:false}}
};
if(!('PointerEvent' in window))button.onmousedown=e=>button.onpointerdown(e);
button.ondragstart=e=>{
if(!beginClozeGesture(button,e,true)){e.preventDefault();return}document.querySelector('.cloze-story-ghost')?.remove();document.documentElement.classList.add('cloze-drag-active');button.classList.add('cloze-source-dragging');
if(e.dataTransfer){try{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',clozeChoice(LEVELS[state.level].sections[state.p],clozeDrag.token).word)}catch{}}
};
// Embedded browsers may send dragend without drop. Resolve the release here too.
button.ondragend=e=>{if(validClozeGesture()&&clozeDrag.native){const point=e.clientX||e.clientY?e:clozeDrag.lastPoint||e;dropClozeGesture(point.clientX,point.clientY,null,'native-end')}else finishClozeDrag()};
});
panel.ondragover=e=>{if(!validClozeGesture())return;clozeDrag.lastPoint={clientX:e.clientX,clientY:e.clientY};e.preventDefault();if(e.dataTransfer){try{e.dataTransfer.dropEffect='move'}catch{}}highlightClozeDrop(clozeDropAt(e.clientX,e.clientY,e.target))};
panel.ondrop=e=>{if(!validClozeGesture())return;e.preventDefault();e.stopPropagation();dropClozeGesture(e.clientX,e.clientY,e.target,'native')};
panel.ondragleave=e=>{if(!e.relatedTarget?.nodeType||!panel.contains(e.relatedTarget))highlightClozeDrop({})};
}
function clozeReadAloud(section){
const answers=state.answers?.[state.p]||{},part=clozeCompact?section.cloze.parts[clozePart(section)]:section.cloze.paragraphs.join(' ');
return [clozeCompact?'Part '+(clozePart(section)+1)+' of '+section.cloze.parts.length+'.':'Complete the story page.',part.replace(/\{\{(c\d+)\}\}/g,(_,id)=>clozeChoice(section,answers[id])?.word||'blank '+(Number(id.slice(1))+1)), 'Word bank: '+section.cloze.bank.map(word=>word.word).join('. ')+'.'];
}
function clozeReportRows(level,answers,pageTimes){
return LEVELS[level].sections.flatMap((section,p)=>(section.cloze?.blanks||[]).map((blank,i)=>{
const response=clozeChoice(section,answers[p]?.[blank.id])?.word||'';
return {section:p+1,item:'C'+(i+1),type:'Cloze',skill:'Vocabulary in context',prompt:blank.prompt,options:section.cloze.bank.map(word=>word.word),instruction:'Drag one word from the word bank into the blank.',response,correct:blank.word,mark:response===blank.word?1:0,seconds:Math.round(pageTimes[p]||0)};
}));
}
