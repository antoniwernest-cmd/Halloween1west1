/* Parent reports reuse Math Landing's offline screen-PDF writer and this
   activity's ZIP, illustration atlas and per-item assessment records. */
const teacherReport={scope:'',unlocked:false,pages:null,report:null};
function parentReportTotal(report){return 1+report.pages.length+(report.mathRows?.length?MATH_PAGES.length:0)}
function teacherScope(report){return report.level+'|'+report.student_id+'|'+report.submitted_at}
function teacherHandoff(report){
if(teacherReport.scope!==teacherScope(report)){teacherReport.scope=teacherScope(report);teacherReport.unlocked=false;teacherReport.pages=null}
teacherReport.report=report;
if(teacherReport.unlocked){teacherReceipt(report);return}
$('app').innerHTML='<main class="completion">'+scene(storyCount(report.level)-1)+'<div class="receipt"><span class="eyebrow">STORY COMPLETE</span><h1>All done!</h1><p class="call-teacher" role="status">Please call your teacher.</p><p>Your story words and question answers are locked. Your teacher will open your results.</p><div class="receipt-meta"><b>Class ID:</b> '+escapeHTML(report.student_id.replace(/-/g,' '))+'<br><b>Level:</b> '+report.level+' · '+LEVELS[report.level].grade+'<br><b>Finished:</b> all 8 story pages and 7 maths breaks</div><button id="teacherAccess" class="quiet">Teacher access</button><form id="teacherCodeForm" class="teacher-code-form" hidden><label for="teacherCode">Teacher code</label><div><input id="teacherCode" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="3" autocomplete="off" aria-label="Teacher code"><button type="submit" class="primary">Open results</button></div><p id="teacherCodeStatus" class="status" role="status"></p></form><small>'+escapeHTML(attemptStorage.mode==='memory'?'Keep this tab open until your teacher saves the results.':'Your teacher can save a parent report and clear the activity for the next student.')+'</small></div></main>';
$('teacherAccess').onclick=()=>{$('teacherCodeForm').hidden=false;$('teacherAccess').hidden=true;$('teacherCode').focus()};
$('teacherCodeForm').onsubmit=e=>{e.preventDefault();if($('teacherCode').value.trim()!=='259'){$('teacherCodeStatus').textContent='Please ask your teacher to enter the code.';$('teacherCode').value='';$('teacherCode').focus();return}teacherReport.unlocked=true;navpush('teacher_results_opened');teacherReceipt(report)};
}
function teacherReceipt(report){
const words=report.clozeTotal||0,combined=report.score+(report.clozeScore||0)+(report.mathScore||0),maximum=report.total+words+(report.mathTotal||0);
$('app').innerHTML='<main class="completion">'+scene(storyCount(report.level)-1)+'<div class="receipt teacher-receipt"><span class="eyebrow">TEACHER RESULTS</span><h1>Ready to share.</h1><p>The parent report includes a summary, 8 story pages and 7 maths pages, with every word choice and question answer.</p><div class="receipt-meta"><b>Class ID:</b> '+escapeHTML(report.student_id.replace(/-/g,' '))+' · <b>Level:</b> '+report.level+'<br><b>Cloze words:</b> '+(report.clozeScore||0)+' / '+words+'<br><b>Questions:</b> '+report.score+' / '+report.total+'<br><b>Combined:</b> '+combined+' / '+maximum+'</div><div class="teacher-tools"><button id="previewParent" class="primary">View / print report</button><button id="downloadParentPng" class="quiet">Download PNG pages</button><button id="downloadXlsx" class="quiet">Download Excel results</button><button id="downloadCsv" class="quiet">Download CSV</button><button id="downloadJson" class="quiet">Save backup</button><button id="endReset" class="quiet">Clear for next student</button></div><p id="downloadStatus" class="saved-state" role="status">'+(attemptStorage.mode==='local'?'Choose a report format for the parent.':'Download the results before refreshing or closing this tab.')+'</p></div></main>';
$('previewParent').onclick=()=>parentAction('preview');$('downloadParentPng').onclick=()=>parentAction('png');
document.querySelector('.teacher-receipt .receipt-meta').insertAdjacentHTML('beforeend','<br><b>Halloween maths:</b> '+(report.mathScore||0)+' / '+(report.mathTotal||0));
$('downloadXlsx').onclick=()=>downloadXLSX(report);$('downloadCsv').onclick=()=>downloadCSV(report);$('downloadJson').onclick=()=>downloadFile(JSON.stringify(report,null,2),'application/json','backup.json');$('endReset').onclick=requestReset;
}
function parentPage(){
const canvas=document.createElement('canvas');canvas.width=1584;canvas.height=1224;const ctx=canvas.getContext('2d');ctx.scale(2,2);ctx.fillStyle='white';ctx.fillRect(0,0,792,612);ctx.strokeStyle='#bbb';return {canvas,ctx};
}
function reportFont(ctx,size=11,bold=false){ctx.font=(bold?'700 ':'')+size+'px Arial';ctx.fillStyle='#222';ctx.textBaseline='alphabetic'}
function reportLines(ctx,text,width,size=11,bold=false){
reportFont(ctx,size,bold);const lines=[];for(const paragraph of String(text??'').split('\n')){let line='';for(const word of paragraph.split(/\s+/)){if(line&&ctx.measureText(line+' '+word).width>width){lines.push(line);line=word}else line+=(line?' ':'')+word}lines.push(line)}return lines;
}
function reportText(ctx,text,x,y,width,size=11,bold=false,leading=size*1.28){
const lines=reportLines(ctx,text,width,size,bold);for(const line of lines){ctx.fillText(line,x,y);y+=leading}return y;
}
function reportRule(ctx,x,y,w){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w,y);ctx.stroke()}
function reportPicture(ctx,image,page,x,y,w,h){const sw=image.naturalWidth/3,sh=image.naturalHeight/2;ctx.drawImage(image,(page%3)*sw,Math.floor(page/3)*sh,sw,sh,x,y,w,h)}
function reportHeading(ctx,title,subtitle,page,total){
reportText(ctx,'HALLOWEEN READING · PARENT REPORT',28,26,736,9,true);reportText(ctx,title,28,51,736,22,true);reportText(ctx,subtitle,28,70,736,10);reportRule(ctx,28,80,736);
reportRule(ctx,28,584,736);reportText(ctx,'The Tiny Pumpkin Story · Story words, comprehension and maths',28,600,620,8.5);reportText(ctx,'Page '+page+' of '+total,708,600,60,8.5);
}
function reportDate(iso){try{return new Intl.DateTimeFormat('en-CA',{year:'numeric',month:'long',day:'numeric',timeZone:'America/Toronto'}).format(new Date(iso))}catch{return String(iso||'').slice(0,10)}}
async function makeParentMathPage(report,p,pageNumber,totalPages){
const {canvas,ctx}=parentPage(),page=MATH_PAGES[p],rows=(report.mathRows||[]).filter(row=>row.section===p+1),score=rows.reduce((sum,row)=>sum+row.mark,0);
reportHeading(ctx,'Math break '+(p+1)+' · '+page.title,report.student_id.replace(/-/g,' ')+' · Patterning and number sense · '+score+' / 3',pageNumber,totalPages);
for(let i=0;i<page.questions.length;i++){
const question=page.questions[i],row=rows[i],x=28+i*251,w=234;ctx.strokeStyle='#c9bda7';ctx.strokeRect(x,100,w,445);let y=reportText(ctx,(i+1)+'. '+question.prompt,x+12,124,w-24,12,true,16);
const picture=new Image();picture.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(mathVisualSVG(question));await picture.decode();ctx.drawImage(picture,x+9,y+12,w-18,124);y+=151;
y=reportText(ctx,'Choices',x+12,y,w-24,11,true);question.choices.forEach((choice,j)=>{y=reportText(ctx,String.fromCharCode(65+j)+'. '+choice,x+12,y+7,w-24,11,false,14)});
y=reportText(ctx,'Student: '+(row.response||'No response'),x+12,y+26,w-24,11,true,15);y=reportText(ctx,'Expected: '+row.correct,x+12,y+10,w-24,11,false,15);reportText(ctx,'Mark: '+row.mark+' / 1',x+12,y+14,w-24,12,true);
if(y+14>570)throw new Error('Math report layout overflow');
}
return {canvas,title:'Math '+(p+1)+' · '+page.title};
}
async function makeParentPages(report){
const image=new Image();image.src=art;await image.decode();const pages=[],id=report.student_id.replace(/-/g,' '),clozeRows=report.clozeRows||[];
let {canvas,ctx}=parentPage();const totalPages=parentReportTotal(report);reportHeading(ctx,'Reading, patterns and number sense',id+' · Level '+report.level+' · '+report.grade+' · '+reportDate(report.submitted_at),1,totalPages);
const words=report.clozeTotal||0,wordScore=report.clozeScore||0,total=report.total+words+(report.mathTotal||0),score=report.score+wordScore+(report.mathScore||0);
reportText(ctx,'Story words: '+wordScore+' / '+words,28,115,530,14,true);reportText(ctx,'Question answers: '+report.score+' / '+report.total,28,142,530,14,true);reportText(ctx,'Halloween maths: '+(report.mathScore||0)+' / '+(report.mathTotal||0),28,169,530,14,true);reportText(ctx,'Combined result: '+score+' / '+total+'  ('+Math.round(score/Math.max(1,total)*100)+'%)',28,201,530,15,true);
reportPicture(ctx,image,storyArtPage(report.level,report.pages.length-1),638,96,94,141);
reportText(ctx,'Story',28,251,50,11,true);reportText(ctx,'Title',72,251,210,11,true);reportText(ctx,'Words',300,251,65,11,true);reportText(ctx,'Questions',382,251,85,11,true);reportRule(ctx,28,261,434);
for(let p=0;p<report.pages.length;p++){const y=284+p*30,wordRows=clozeRows.filter(row=>row.section===p+1);reportText(ctx,String(p+1),28,y,35,10.5);reportText(ctx,sectionTitle(report.level,p),72,y,212,10.5);reportText(ctx,wordRows.reduce((sum,row)=>sum+row.mark,0)+'/'+wordRows.length,300,y,65,10.5);reportText(ctx,report.pages[p].score+'/'+report.pages[p].maximum,382,y,75,10.5);reportRule(ctx,28,y+9,434)}
reportText(ctx,'Math break',492,251,165,11,true);reportText(ctx,'Mark',700,251,60,11,true);reportRule(ctx,492,261,270);
for(let p=0;p<MATH_PAGES.length;p++){const rows=(report.mathRows||[]).filter(row=>row.section===p+1),y=284+p*30;reportText(ctx,(p+1)+'. '+MATH_PAGES[p].title,492,y,200,10.5);reportText(ctx,rows.reduce((sum,row)=>sum+row.mark,0)+'/'+rows.length,700,y,60,10.5);reportRule(ctx,492,y+9,270)}
reportText(ctx,'Together at home',28,541,730,12,true);reportText(ctx,'Talk about a story detail, then try a pattern or counting question together. The following pages show every response and expected answer.',28,561,730,10.5);
pages.push({canvas,title:'Assessment summary'});
for(let p=0;p<report.pages.length;p++){
({canvas,ctx}=parentPage());const section=LEVELS[report.level].sections[p],wordsForPage=clozeRows.filter(row=>row.section===p+1),questions=report.rows.filter(row=>row.section===p+1),wordMarks=wordsForPage.reduce((sum,row)=>sum+row.mark,0);
reportHeading(ctx,'Section '+(p+1)+' · '+sectionTitle(report.level,p),id+' · Level '+report.level+' · Words '+wordMarks+'/'+wordsForPage.length+' · Questions '+report.pages[p].score+'/'+report.pages[p].maximum,pages.length+1,totalPages);
reportText(ctx,'Story as completed',28,101,322,12,true);let leftY=122;const longStory=section.text.join(' ').split(/\s+/).length>180,storySize=longStory?10.2:10.8,storyLeading=longStory?12.5:14,pictureHeight=longStory?96:120;
for(const paragraph of section.cloze.paragraphs){
const completed=paragraph.replace(/\{\{c(\d+)\}\}/g,(_,n)=>{const row=wordsForPage[Number(n)];return '['+(Number(n)+1)+'] '+(row.response||'______')});leftY=reportText(ctx,completed,28,leftY,320,storySize,false,storyLeading)+7;
}
const pictureY=leftY+5;reportPicture(ctx,image,storyArtPage(report.level,p),28,pictureY,pictureHeight*2/3,pictureHeight);
let bankY=reportText(ctx,'Word bank',121,pictureY+12,227,11,true);bankY=reportText(ctx,section.cloze.bank.map(word=>word.word).join(' · '),121,bankY+5,227,10.5,false,14);
reportText(ctx,'[1], [2] and so on show the student’s filled blanks. The expected words appear in the table.',121,bankY+15,227,10,false,13);
let rightY=101;reportText(ctx,'Story words',377,rightY,385,12,true);rightY+=19;
ctx.fillStyle='#eee9df';ctx.fillRect(377,rightY-12,387,20);reportText(ctx,'Blank',384,rightY+2,38,10,true);reportText(ctx,'Student chose',426,rightY+2,123,10,true);reportText(ctx,'Expected word',554,rightY+2,125,10,true);reportText(ctx,'Mark',712,rightY+2,45,10,true);rightY+=24;
wordsForPage.forEach((row,i)=>{reportText(ctx,String(i+1),384,rightY,36,10.5);reportText(ctx,row.response||'No response',426,rightY,122,10.5);reportText(ctx,row.correct,554,rightY,132,10.5);reportText(ctx,row.mark+' / 1',712,rightY,45,10.5);reportRule(ctx,377,rightY+7,387);rightY+=23});
rightY+=9;reportText(ctx,'Question answers',377,rightY,387,12,true);rightY+=18;
for(const row of questions){
rightY=reportText(ctx,row.item+'. '+row.prompt+'   ['+row.mark+'/1]',377,rightY,387,10.2,true,12.5);
rightY=reportText(ctx,'Choices: '+row.options.map((choice,i)=>String.fromCharCode(65+i)+'. '+choice).join('  /  '),377,rightY+2,387,9.8,false,12);
rightY=reportText(ctx,'Student: '+(row.response||'No response')+'   |   Expected: '+row.correct,377,rightY+2,387,10.1,false,12.5)+10;
}
if(Math.max(pictureY+pictureHeight,rightY)>579)throw new Error('Report layout overflow in section '+(p+1));
pages.push({canvas,title:'Story '+(p+1)+' · '+sectionTitle(report.level,p)});
if(p<MATH_PAGES.length)pages.push(await makeParentMathPage(report,p,pages.length+1,totalPages));
}
return pages;
}
async function parentAction(action){
if(!teacherReport.unlocked)return;const status=$('downloadStatus');status.textContent='Preparing the complete parent report…';
try{
teacherReport.pages||=await makeParentPages(teacherReport.report);
if(action==='preview'){showParentPreview();status.textContent='Parent report ready: '+teacherReport.pages.length+' pages.';return}
if(action==='pdf'){
const pdf=new window.ML_SCREEN_PDF({width:792,height:612});for(const page of teacherReport.pages)await pdf.addPNG(page.canvas.toDataURL('image/png'));
downloadFile(pdf.finish(),'application/pdf','Parent-Assessment.pdf',teacherReport.report);status.textContent='Parent assessment PDF downloaded: '+teacherReport.pages.length+' pages.';
}else{
const files={};for(let i=0;i<teacherReport.pages.length;i++){const blob=await new Promise(resolve=>teacherReport.pages[i].canvas.toBlob(resolve,'image/png'));files[String(i+1).padStart(2,'0')+'-'+(i===0?'Summary':'Page-'+i)+'.png']=new Uint8Array(await blob.arrayBuffer())}
const blob=new Blob([zipStored(files)],{type:'application/zip'});downloadFile(blob,'application/zip','Parent-Assessment-PNG-Pages.zip',teacherReport.report);status.textContent='PNG pages downloaded in one ZIP: '+teacherReport.pages.length+' images.';
}
navpush('parent_report_download',action);
}catch(error){status.textContent='The parent report could not finish. Your answers are safe; use the Excel report.';console.error(error)}
}
function showParentPreview(){
let dialog=$('parentReportDialog');if(!dialog){dialog=document.createElement('dialog');dialog.id='parentReportDialog';dialog.setAttribute('aria-label','Parent assessment report');document.body.append(dialog)}
dialog.innerHTML='<div class="parent-report-toolbar"><label for="parentReportPage">Report page <select id="parentReportPage" aria-label="Report page">'+teacherReport.pages.map((page,i)=>'<option value="'+i+'">'+escapeHTML(page.title)+'</option>').join('')+'</select></label><button id="printParentReport" class="primary">Print report</button><button id="closeParentReport" class="quiet">Close</button></div><div id="parentCanvasHost"></div>';
const show=()=>{$('parentCanvasHost').replaceChildren(teacherReport.pages[Number($('parentReportPage').value)].canvas)};show();$('parentReportPage').onchange=show;$('closeParentReport').onclick=()=>dialog.close();$('printParentReport').onclick=printParentReport;dialog.showModal();
}
async function printParentReport(){
if(!teacherReport.unlocked||!teacherReport.pages)return;let printHost=$('parentPrintReport');if(!printHost){printHost=document.createElement('div');printHost.id='parentPrintReport';document.body.append(printHost)}
printHost.replaceChildren(...teacherReport.pages.map(page=>{const image=document.createElement('img');image.src=page.canvas.toDataURL('image/png');image.alt=page.title;return image}));await Promise.all([...printHost.children].map(image=>image.decode()));document.body.classList.add('printing-parent-report');window.print();document.body.classList.remove('printing-parent-report');
}
